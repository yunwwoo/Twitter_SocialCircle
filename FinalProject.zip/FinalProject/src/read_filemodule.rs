use std::io::BufRead;
use std::fs::File;

pub fn read_file(path: &str) -> Vec<(usize, usize)> {
    let mut result: Vec<(usize, usize)> = Vec::new();
    let file = File::open(path).expect("Could not open file");
    let buf_reader = std::io::BufReader::new(file).lines();
    for line in buf_reader {
        let line_str = line.expect("Error reading");
        let v: Vec<&str> = line_str.trim().split(' ').collect();
        let x = v[0].parse::<u128>().unwrap();
        let y = v[1].parse::<u128>().unwrap();

        result.push((x as usize, y as usize));

    }
    return result;
}
