type Vertex = usize;
type ListOfEdges = Vec<(Vertex,Vertex)>;
type AdjacencyLists = Vec<Vec<Vertex>>;

use std::collections::VecDeque;
use std::collections::HashMap;

use std::io::BufRead;
use std::fs::File;


#[derive(Debug)]

struct Graph {
    n: usize,
    outedges: AdjacencyLists,
}

impl Graph {

    fn add_directed_edges(&mut self, edges:&ListOfEdges) {
        for (u,v) in edges {
            self.outedges[*u].push(*v);
            println!("u {:?} v{:?}",u,v);

        }
    }

    fn sort_graph_lists(&mut self) {
        for l in self.outedges.iter_mut() {
            l.sort();
        }
    }

    fn create_directed(n:usize,edges:&ListOfEdges) -> Graph {
        let mut g = Graph{n,outedges:vec![vec![];n]};
        g.add_directed_edges(edges);
        g.sort_graph_lists();
        g                                        
    }

    fn compute_and_print_distance_bfs(start: Vertex, graph: &Graph) {
        let mut distance_vec = vec![];
        let mut count_dis:i128=0;
        let mut total_avgdis:i128=0;
        let mut avg_distance:i128 =0;
        let mut distance: Vec<Option<u32>> = vec![None;graph.n];
        distance[start] = Some(0); //start point
        let mut queue: VecDeque<Vertex> = VecDeque::new();
        queue.push_back(start);
        while let Some(v) = queue.pop_front() { // new unprocessed vertex
            for u in graph.outedges[v].iter() {
                if let None = distance[*u] { // consider all unprocessed neighbors of v
                    distance[*u] = Some(distance[v].unwrap() + 1);
                    queue.push_back(*u);
                }
            }
        }
        print!("vertex:distance");
        for v in 0..graph.n {
            if distance[v]!=None{
                distance_vec.push(distance[v].unwrap());
            }
        }
        println!();

        for i in &distance_vec{
            count_dis += *i as i128;
            avg_distance = count_dis/(distance_vec.len()) as i128;
            

        }
        println!("average distance of all nodes from {}: {}", start, avg_distance);   
    }
}
    // These functions are not exactly from my functions in main.rs but I want to test if some functions I used inside main functions are correct
    pub fn sort_graph_lists(test_edge: &mut Vec<(usize,usize)>){
        test_edge.sort();

    }

    pub fn max_connection_finding(test_edge: &mut Vec<i32>) -> i32{
        let mut v1:i32 = *test_edge.iter().max().unwrap();
        v1

    }

    pub fn min_connection_finding(test_edge: &mut Vec<i32>) -> i32{
        let mut v2:i32 = *test_edge.iter().min().unwrap();
        v2

    }
    

    pub fn using_forward_hashtable (edges:&ListOfEdges) -> HashMap<usize, usize> {
        let mut count:i32=0;
        let mut forward_map: HashMap<usize, usize> = HashMap::new();
        for (i, z) in edges.iter() {
            if forward_map.get(i) == None {
                forward_map.insert(*i, count.try_into().unwrap());
                count = count + 1;
            }

    }
    forward_map
}



#[test]
fn test_directed_edges_withsmall_posnums() {
    let mut count_test = vec![];
    let mut edges: ListOfEdges = vec![(0,1),(1,2),(2,4),(2,3),(4,3),(4,5),(5,6),(4,6),(6,8),(8,7),(1,9)];
    let mut graph = Graph::create_directed(10,&edges);
    for (i, l) in graph.outedges.iter().enumerate(){
        count_test.push(l.len());     //count the length of neighbors 

    }
    assert_eq!(count_test,[1, 2, 2, 0, 3, 1, 1, 0, 1, 0]);
}

#[test]
fn test_directed_edges_withlargenums() {
    let mut count_test2 = vec![];
    let mut edges: ListOfEdges = vec![(100,12),(100,30),(20,4),(20,3),(4,3),(4,5),(5,6),(4,6),(68,8),(68,7),(1,9)];
    let mut graph = Graph::create_directed(101,&edges);
    for (i, l) in graph.outedges.iter().enumerate(){
        count_test2.push(l.len());     //count the length of neighbors 

    }
    println!("count_test {:?}",count_test2);
    assert_eq!(count_test2,[0, 1, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2]);
}

    #[test]
    fn test_sort_graph_lists() {
        let mut edges = vec![(0,1),(0,2),(1,2),(2,4),(2,3),(4,3),(4,5),(5,6),(4,6),(6,8),(6,7),(8,7),(1,9)];
        sort_graph_lists(&mut edges);
        assert_eq!(edges,vec![(0, 1), (0, 2), (1, 2), (1, 9), (2, 3), (2, 4), (4, 3), (4, 5), (4, 6), (5, 6), (6, 7), (6, 8), (8, 7)]);
    }

    #[test]
    fn test_max_connection (){
        let mut v1 = vec![1,3,4,100,98,45,101];
        let mut max_v1:i32 = max_connection_finding(&mut v1);
        assert_eq!(max_v1, 101);

    }

    #[test]
    fn test_min_connection (){
        let mut v1 = vec![1,3,4,100,98,45,101];
        let mut min_v1:i32 = min_connection_finding(&mut v1);
        println!("v1{}",min_v1);
        assert_eq!(min_v1, 1);

    }

    #[test]
    fn test_forward_hashtable(){
        let mut edges: ListOfEdges = vec![(0,1),(1,2),(2,4),(2,3),(4,3),(4,5),(5,6),(4,6),(6,8),(8,7),(1,9)];
        let mut forward_map_test: HashMap<usize, usize> = HashMap::new();
        let mut i= forward_map_test.get(&4);
        assert_eq!(i,None);
        
    }
