type Vertex = usize;
type ListOfEdges = Vec<(Vertex,Vertex)>;
type AdjacencyLists = Vec<Vec<Vertex>>;

use std::collections::VecDeque;
use std::collections::HashMap;

mod read_filemodule;

#[derive(Debug)]

struct Graph {
    n: usize,
    outedges: AdjacencyLists,
}


impl Graph {

    fn add_directed_edges(&mut self, edges:&ListOfEdges) {
        for (u,v) in edges {
            self.outedges[*u].push(*v);
            println!("u {:?} v{:?}",u,v);

        }
    }

    fn sort_graph_lists(&mut self) {
        for l in self.outedges.iter_mut() {
            l.sort();
        }
    }

    fn create_directed(n:usize,edges:&ListOfEdges) -> Graph {
        let mut g = Graph{n,outedges:vec![vec![];n]};
        g.add_directed_edges(edges);
        g.sort_graph_lists();
        g                                        
    }

    fn compute_and_print_distance_bfs(start: Vertex, graph: &Graph) {
        let mut distance_vec = vec![];
        let mut count_dis:i128=0;
        let mut total_avgdis:i128=0;
        let mut avg_distance:i128 =0;
        let mut distance: Vec<Option<u32>> = vec![None;graph.n];
        distance[start] = Some(0); //start point
        let mut queue: VecDeque<Vertex> = VecDeque::new();
        queue.push_back(start);
        while let Some(v) = queue.pop_front() { // new unprocessed vertex
            for u in graph.outedges[v].iter() {
                if let None = distance[*u] { // consider all unprocessed neighbors of v
                    distance[*u] = Some(distance[v].unwrap() + 1);
                    queue.push_back(*u);
                }
            }
        }
        print!("vertex:distance");
        for v in 0..graph.n {
            if distance[v]!=None{
                distance_vec.push(distance[v].unwrap());
            }
        }
        println!();

        for i in &distance_vec{
            count_dis += *i as i128;
            avg_distance = count_dis/(distance_vec.len()) as i128;
            

        }
        println!("average distance of all nodes from {}: {}", start, avg_distance);   
    }
}



fn main() {
    let mut read_edges = read_filemodule::read_file("twitter_combined.txt");
    let mut forward_map: HashMap<usize, usize> = HashMap::new();
    let mut backward_map: HashMap<usize, usize> = HashMap::new();
    let mut count = 0;    
    let mut n:usize = 2420766;    
    let mut count_vec = vec![];
    let mut last_ivec = vec![];


//pre processing dataset with hash table
    for (i, z) in read_edges.iter() {
        if forward_map.get(i) == None {
            forward_map.insert(*i, count);
            backward_map.insert(count, *i);
            count = count + 1;
        }
        if forward_map.get(z) == None {
            forward_map.insert(*z, count);
            backward_map.insert(count, *z);
            count = count + 1;
        }
    }
    let mut final_edges: Vec<(usize, usize)> = vec![];
    for (i, z) in read_edges.iter() {
        let u = forward_map.get(i).unwrap();
        let v = forward_map.get(z).unwrap();
        final_edges.push((*u,*v));
    }

    let mut graph = Graph::create_directed(n,&final_edges);
    
    for (i, l) in graph.outedges.iter().enumerate(){
        count_vec.push(l.len());     //count the length of neighbors 
        last_ivec.push(i);

    }

    count_vec.sort();
    last_ivec.sort();
    println!("last element: {} ", last_ivec[last_ivec.len()-1]);  //last node number 


    let min_value:usize = *count_vec.iter().min().unwrap();
    let max_value:usize = *count_vec.iter().max().unwrap();
    println!("min connections: {} ",min_value);
    println!("max connections: {} ",max_value);

    //breath first searach from all the nodes print distance 
    for i in 0..graph.n {
        println!("Distances from node {}", i);
        Graph::compute_and_print_distance_bfs(i, &graph);
}


}
